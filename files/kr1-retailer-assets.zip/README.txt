KR1 PUBLISHING RETAILER ASSETS
contact@kr1publishing.com · kr1publishing.com/vendor · kr1publishing.com/assets
Updated 27 September 2026

This pack is for retailers who carry or are onboarding KR1 titles and need
cover art, product data, mockups and reading copies for their own webshop,
POS system, staff and social channels.

CONTENTS
- kr1-retailer-catalog.xlsx
  Five tabs. Start: what is where. EN Product data / NO Produktdata: one row per
  title with barcode, ISBN, format, pages, trim size, RRP in USD, NOK, SEK
  and EUR, and copies sold, in English and Norwegian. EN Product text /
  NO Produkttekst: web shop text per title in blocks (hook, description,
  bullet points, perfect for, credits) plus everything in one cell.
- kr1-retailer-catalog.csv
  The product data table only, semicolon separated, for import.

- covers/
  Flat cover art, one JPG per title at print resolution (300 dpi), except
  Silverheart which is web resolution for now. Write to
  contact@kr1publishing.com and we send the print file.

- mockups/
  One PNG per title with transparent background: the softcover rendered
  in perspective with spine and page edges, about 1250 px on the long
  side. Ready for a product listing, newsletter or social post without
  editing.

- Reading copies (on the website)
  PDF reading copies of all 11 English titles, cover included, are on
  each title card at kr1publishing.com/assets, so your staff can read
  before they sell. They are for internal use in your shop, please do
  not redistribute or sell the PDFs.

- logo/
  The KR1 hex mark and the KR1 Publishing lockup, each in a version for
  light and for dark backgrounds, as PNG and SVG. For shelf talkers, web
  listings and social posts.

ON PRODUCT CODES
Every title shows the barcode printed on the book. Scan it at the till or
use it as the supplier code in your system. If your system needs something
else, tell us.

ABOUT KR1 PUBLISHING
A tabletop RPG publisher in Kongsberg, Norway, run by Karl Otto
Kristoffersen together with a network of authors, illustrators and partner
studios. Over 15,000 books sold. The West Marches Guidebook is the best
seller with 4,450+ copies, and the Hexcrawl series (with Matthijs Holter)
has three books in print and 6,500+ copies sold. KR1 finished eighth in
Geek Native's 2025 DriveThruRPG publisher league table.

Prices and specs valid for the 2026 season. Ask for a written quote before
you order and the amount is fixed. Margins, ordering and the full stockist
list: kr1publishing.com/vendor
