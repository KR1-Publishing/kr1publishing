KR1 PUBLISHING RETAILER ASSETS
contact@kr1publishing.com · kr1publishing.com/vendor · kr1publishing.com/assets
Updated 27 September 2026

This pack is for retailers who carry or are onboarding KR1 titles and need
cover art, product data, mockups and reading copies for their own webshop,
POS system, staff and social channels.

CONTENTS
- kr1-retailer-catalog.xlsx and .csv
  One row per title. Columns A to M are data for your product system:
  barcode, ISBN, format, pages, trim size, RRP in USD, NOK, SEK and EUR,
  and copies sold. Columns N to S are web shop text, in pieces (hook,
  description, bullet points, perfect for, credits) and as one full text.
  The CSV has the data columns only, semicolon separated, for import.

- covers/
  Flat cover art, one JPG per title at print resolution (300 dpi), except
  Silverheart which is web resolution for now. Write to
  contact@kr1publishing.com and we send the print file.

- mockups/
  One PNG per title with transparent background: the softcover rendered
  in perspective with spine and page edges, 1254 x 1254 px, 256-colour PNG. Ready for a
  product listing, newsletter or social post without editing.

- Reading copies (separate download)
  Full PDF reading copies of all 11 English titles, cover included, are
  available as single PDFs on each title card at kr1publishing.com/assets, so your staff can read before they sell.
  They are for internal use in your shop, please do not redistribute
  or sell the PDFs.

- logo/
  The KR1 hex mark and the KR1 Publishing lockup, each in a version for
  light and for dark backgrounds, as PNG and SVG. For shelf talkers, web
  listings and social posts.

ON PRODUCT CODES
Every title shows the barcode printed on the book. Scan it at the till or
use it as the supplier code in your system. If your system needs something
else, tell us.

ABOUT KR1 PUBLISHING
A tabletop RPG publisher in Kongsberg, Norway, run by Karl Otto
Kristoffersen together with a network of authors, illustrators and partner
studios. The West Marches Guidebook holds a Mithral bestseller medal
on DriveThruRPG with 4,000+ copies sold. The Hexcrawl series (with
Matthijs Holter) has three books in print, all medalled. KR1 finished
eighth in Geek Native's 2025 DriveThruRPG publisher league table.

Prices and specs valid for the 2026 season. Ask for a written quote before
you order and the amount is fixed. Margins, ordering and the full stockist
list: kr1publishing.com/vendor
